package lithan.training.javawebapp;

public class CreditCardProcessor implements PaymentProcessor{

	public Boolean process() {
		//process payment via Credit Card
		System.out.println("Payment via Credit Card");
		return true;
	}


}
