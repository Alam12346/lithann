package lithan.training.javawebapp;

public class BillingService {
	
	private PaymentProcessor paymentProcessor;
	
	public Boolean completePayment() {
		return paymentProcessor.process();
	}

	/**
	 * @return the paymentProcessor
	 */
	public PaymentProcessor getPaymentProcessor() {
		return paymentProcessor;
	}

	/**
	 * @param paymentProcessor the paymentProcessor to set
	 */
	public void setPaymentProcessor(PaymentProcessor paymentProcessor) {
		this.paymentProcessor = paymentProcessor;
	}
	
}
