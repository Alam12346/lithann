package lithan.training.javawebapp;

public class PaymentProcessorFactory {
	
	private final GooglePayProcessor gPayProcessor = new GooglePayProcessor();
	private final CreditCardProcessor cardProcessor = new CreditCardProcessor();
	
	// calling the payment processor interface and do a getter
	public PaymentProcessor getPaymentProcessor(String mode) {
		if("gpay".equalsIgnoreCase(mode)) {
			return gPayProcessor;
		}else if("credit_card".equalsIgnoreCase(mode)) {
			return cardProcessor;
		}
		
		return null;
		
	}

}

