package lithan.training.javawebapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
	private static ApplicationContext context1;
	
    public static void main( String[] args )
    {
    	context1 = new ClassPathXmlApplicationContext("Config.xml");
    	BillingService prObj1 = (BillingService) context1.getBean("billingservice");
    	prObj1.completePayment();
    }
}
