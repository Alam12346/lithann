package lithan.training.javawebapp;

public class GooglePayProcessor implements PaymentProcessor{

	public Boolean process() {
		//process payment via Google Pay
		System.out.println("Payment via Google Pay");
		return true;
	}

}
