package lithan.training.javawebapp;

public interface PaymentProcessor {
	
	public Boolean process();

	

}
