package AAACustomerPortlet.constants;

/**
 * @author Administrator
 */
public class AAACustomerPortletKeys {

	public static final String AAACUSTOMER =
		"AAACustomerPortlet_AAACustomerPortlet";

}